import React from 'react';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import { motion } from 'motion/react';

export interface ProductProps {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  image: string;
  category: string;
}

const ProductCard: React.FC<{ product: ProductProps }> = ({ product }) => {
  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="group bg-white rounded-3xl border border-gray-100 overflow-hidden hover:shadow-xl hover:shadow-indigo-100/50 transition-all duration-300"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-gray-50">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-indigo-600 text-xs font-bold rounded-full shadow-sm">
            {discount}% OFF
          </span>
        </div>
        <button className="absolute top-4 right-4 p-2 bg-white/90 backdrop-blur-sm rounded-full text-gray-400 hover:text-red-500 hover:scale-110 transition-all shadow-sm">
          <Heart className="w-5 h-5" />
        </button>
        
        <div className="absolute inset-x-4 bottom-4 translate-y-12 group-hover:translate-y-0 transition-transform duration-300">
          <button className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 hover:bg-indigo-700">
            <ShoppingCart className="w-4 h-4" />
            Add to Cart
          </button>
        </div>
      </div>

      <div className="p-5">
        <p className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-1">{product.category}</p>
        <h3 className="font-bold text-gray-900 mb-2 line-clamp-1 group-hover:text-indigo-600 transition-colors">
          {product.name}
        </h3>
        
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-0.5">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star
                key={i}
                className={`w-3.5 h-3.5 ${
                  i <= Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-200'
                }`}
              />
            ))}
          </div>
          <span className="text-xs font-medium text-gray-400">({product.reviews})</span>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-xl font-extrabold text-gray-900">₹{product.price.toLocaleString()}</span>
          <span className="text-sm text-gray-400 line-through">₹{product.originalPrice.toLocaleString()}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;

