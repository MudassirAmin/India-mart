import ProductCard, { ProductProps } from './ProductCard';
import { ArrowRight } from 'lucide-react';

const MOCK_PRODUCTS: ProductProps[] = [
  {
    id: 1,
    name: "Premium Wireless Headphones",
    price: 12999,
    originalPrice: 19999,
    rating: 4.8,
    reviews: 1240,
    image: "https://picsum.photos/seed/headphones/600/800",
    category: "Electronics"
  },
  {
    id: 2,
    name: "Smart Watch Series 7",
    price: 24999,
    originalPrice: 32999,
    rating: 4.9,
    reviews: 850,
    image: "https://picsum.photos/seed/watch/600/800",
    category: "Electronics"
  },
  {
    id: 3,
    name: "Cotton Casual Shirt",
    price: 1499,
    originalPrice: 2999,
    rating: 4.5,
    reviews: 2100,
    image: "https://picsum.photos/seed/shirt/600/800",
    category: "Fashion"
  },
  {
    id: 4,
    name: "Running Sports Shoes",
    price: 3999,
    originalPrice: 5999,
    rating: 4.7,
    reviews: 1500,
    image: "https://picsum.photos/seed/shoes/600/800",
    category: "Fashion"
  }
];

export default function CategorySection({ title }: { title: string }) {
  return (
    <section className="py-16 bg-gray-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight mb-2">{title}</h2>
            <div className="h-1.5 w-20 bg-indigo-600 rounded-full" />
          </div>
          <button className="flex items-center gap-2 text-indigo-600 font-bold hover:gap-3 transition-all">
            View All
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {MOCK_PRODUCTS.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
