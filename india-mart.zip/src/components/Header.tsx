import { Search, ShoppingCart, User, Menu, Heart } from 'lucide-react';
import { motion } from 'motion/react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center gap-2">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
              IM
            </div>
            <span className="text-2xl font-bold tracking-tight text-gray-900 hidden sm:block">
              India<span className="text-indigo-600">Mart</span>
            </span>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-2xl hidden md:block">
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400 group-focus-within:text-indigo-600 transition-colors" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2.5 border border-gray-200 rounded-2xl leading-5 bg-gray-50 placeholder-gray-500 focus:outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent sm:text-sm transition-all"
                placeholder="Search for products, brands and more..."
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 sm:gap-6">
            <button className="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-all md:hidden">
              <Search className="h-6 w-6" />
            </button>
            <button className="flex items-center gap-2 text-gray-700 hover:text-indigo-600 font-medium transition-colors">
              <User className="h-6 w-6" />
              <span className="hidden lg:block">Login</span>
            </button>
            <button className="relative p-2 text-gray-700 hover:text-indigo-600 transition-colors">
              <Heart className="h-6 w-6" />
              <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                2
              </span>
            </button>
            <button className="relative p-2 text-gray-700 hover:text-indigo-600 transition-colors">
              <ShoppingCart className="h-6 w-6" />
              <span className="absolute top-0 right-0 h-4 w-4 bg-indigo-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                3
              </span>
            </button>
            <button className="p-2 text-gray-500 hover:text-indigo-600 md:hidden">
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Categories Nav */}
        <nav className="hidden md:flex items-center gap-8 py-3 text-sm font-medium text-gray-600">
          {['Electronics', 'Fashion', 'Home & Kitchen', 'Beauty', 'Books', 'Sports'].map((cat) => (
            <a
              key={cat}
              href="#"
              className="hover:text-indigo-600 transition-colors relative group"
            >
              {cat}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-indigo-600 transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
