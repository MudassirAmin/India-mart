/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Header from './components/Header';
import Hero from './components/Hero';
import CategorySection from './components/CategorySection';
import { motion } from 'motion/react';
import { Truck, ShieldCheck, RotateCcw, Headphones } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-white font-sans selection:bg-indigo-100 selection:text-indigo-900">
      <Header />
      
      <main>
        <Hero />
        
        {/* Features Bar */}
        <section className="py-12 border-y border-gray-100 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: Truck, title: "Free Shipping", desc: "On orders over ₹999" },
                { icon: ShieldCheck, title: "Secure Payment", desc: "100% protected payments" },
                { icon: RotateCcw, title: "Easy Returns", desc: "30-day return policy" },
                { icon: Headphones, title: "24/7 Support", desc: "Dedicated support team" }
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 flex-shrink-0">
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 text-sm">{feature.title}</h4>
                    <p className="text-xs text-gray-500">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <CategorySection title="Trending Now" />
        
        {/* Banner Section */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="relative rounded-[3rem] overflow-hidden bg-indigo-900 h-[400px] flex items-center">
              <img
                src="https://picsum.photos/seed/banner/1200/600"
                alt="Banner"
                className="absolute inset-0 w-full h-full object-cover opacity-40"
                referrerPolicy="no-referrer"
              />
              <div className="relative z-10 px-12 sm:px-20 max-w-2xl">
                <h2 className="text-4xl sm:text-6xl font-extrabold text-white mb-6 leading-tight">
                  Upgrade Your Home with Smart Tech.
                </h2>
                <p className="text-indigo-100 text-lg mb-8">
                  Save up to 40% on the latest smart home appliances and gadgets.
                </p>
                <button className="px-8 py-4 bg-white text-indigo-900 rounded-2xl font-bold text-lg hover:bg-indigo-50 transition-all">
                  Shop Appliances
                </button>
              </div>
            </div>
          </div>
        </section>

        <CategorySection title="Best Sellers" />
      </main>

      <footer className="bg-gray-900 text-white pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
                  IM
                </div>
                <span className="text-2xl font-bold tracking-tight">
                  India<span className="text-indigo-600">Mart</span>
                </span>
              </div>
              <p className="text-gray-400 leading-relaxed mb-6">
                India's leading e-commerce destination for quality products and exceptional service.
              </p>
              <div className="flex gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-10 h-10 bg-gray-800 rounded-full hover:bg-indigo-600 transition-colors cursor-pointer" />
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-bold text-lg mb-6">Quick Links</h4>
              <ul className="space-y-4 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Press</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-6">Customer Service</h4>
              <ul className="space-y-4 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Returns & Refunds</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Shipping Info</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Track Order</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-6">Newsletter</h4>
              <p className="text-gray-400 mb-6">Subscribe to get special offers and once-in-a-lifetime deals.</p>
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="Your email"
                  className="bg-gray-800 border-none rounded-xl px-4 py-3 flex-1 focus:ring-2 focus:ring-indigo-600 outline-none"
                />
                <button className="bg-indigo-600 hover:bg-indigo-700 px-6 py-3 rounded-xl font-bold transition-all">
                  Join
                </button>
              </div>
            </div>
          </div>
          
          <div className="pt-10 border-t border-gray-800 flex flex-col md:row items-center justify-between gap-6 text-gray-500 text-sm">
            <p>© 2026 India Mart. All rights reserved.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

